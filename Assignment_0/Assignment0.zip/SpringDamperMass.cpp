#include "SpringDamperMass.h"

// TODO
// Define your methods here
